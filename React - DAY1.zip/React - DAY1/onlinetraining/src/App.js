import React from "react";
import ListOfCourses from "./components/listofcourses.component";

class App extends React.Component {
  render() {
    return (
      <div>
        <ListOfCourses />
      </div>
    );
  }
}

export default App;
