import React from "react";
class Course extends React.Component {
  IncrementLikes() {
    // console.log("Within Increment Likes !");
    // console.log(this);
    this.props.coursedetails.likes++; // props are readonly !
    console.log(this.props.coursedetails.likes);
  }
  render() {
    var ratings = [];
    for (let index = 0; index < this.props.coursedetails.rating; index++) {
      ratings.push(
        <i className="fa-solid fa-star" style={{ color: "#fab005" }}></i>
      );
    }
    return (
      <div className="col-md-3 my-1">
        <div className="card">
          <img
            height="160px"
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            className="card-img-top"
          />
          <div className="card-body">
            <h4 className="card-title">{this.props.coursedetails.title}</h4>
            <h5 className="card-text">₹. {this.props.coursedetails.price}</h5>
            <p>{ratings}</p>

            <button
              className="btn btn-primary"
              onClick={() => this.IncrementLikes()}
            >
              {this.props.coursedetails.likes}{" "}
              <i className="fa-solid fa-thumbs-up"></i>
            </button>

            <button className="btn btn-danger mx-1">
              <i className="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
